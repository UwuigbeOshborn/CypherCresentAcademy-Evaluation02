﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2
{
    public class Class6
    {
        //Constructors
        public Class6()
        {

        }
        //Methods

        //Properties

    }
}
