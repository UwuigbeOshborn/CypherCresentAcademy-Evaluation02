﻿// See https://aka.ms/new-console-template for more information
using OshbornCCSAevaluation2;
using OshbornCCSAevaluation2.Helpers;

FluentNHibernateHelper.ResetSessionFactory();
FluentNHibernateHelper.OpenSession();

Console.WriteLine("Welcome to Oshborn's Hospital Management System!\n");


var royalHealthCare = new Hospital() { Name = "Royal Health Care", Address = "N0. 20 PTI road warri, Delta state." };
DataBaseManager.AddItem(royalHealthCare);


var receptionistCollins = new Receptionist() { Name = "Collins", Hospital = royalHealthCare, Address = "No. 13 Tunde street, Edo state" };
DataBaseManager.AddItem(receptionistCollins);


var doctorMurphy = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state" };
var doctorIfe = new Doctor() { Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH" };
var doctorMark = new Doctor() { Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH" };
var doctorLucky = new Doctor() { Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH" };
var doctorVivian = new Doctor() { Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state" };
DataBaseManager.AddItem(doctorMurphy);
DataBaseManager.AddItem(doctorIfe);
DataBaseManager.AddItem(doctorMark);
DataBaseManager.AddItem(doctorLucky);
DataBaseManager.AddItem(doctorVivian);


var drug1 = new Drug() {Name = "Panadol", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 200m };
var drug2 = new Drug() { Name = "ProCold", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(-2).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 100m };
var drug3 = new Drug() { Name = "Vitamin C", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(-3).AddMonths(-7).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 500m };
var drug4 = new Drug() { Name = "Coartem", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(10).AddMonths(5).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 1500m };
var drug5 = new Drug() { Name = "Lunate DS", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(15).AddMonths(-4).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 800m };
var drug6 = new Drug() { Name = "Crestor", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(4).AddMonths(4).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 400m };
var drug7 = new Drug() { Name = "Amlodipine", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 2000m };
var drug8 = new Drug() { Name = "Ativan", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(22).AddMonths(7).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 2500m };
var drug9 = new Drug() { Name = "Morpine", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(-5).AddMonths(-5).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 300m };
var drug10 = new Drug() { Name = "Tramadol", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(2).AddMonths(10).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 2000m };

DataBaseManager.AddItem(drug1);
DataBaseManager.AddItem(drug2);
DataBaseManager.AddItem(drug3);
DataBaseManager.AddItem(drug4);
DataBaseManager.AddItem(drug5);
DataBaseManager.AddItem(drug6);
DataBaseManager.AddItem(drug7);
DataBaseManager.AddItem(drug8);
DataBaseManager.AddItem(drug9);
DataBaseManager.AddItem(drug10);


var patient1 = new Patient() { Name = "John", Address = "No. 1 Tran Amadi", RegistrationNumber = "2231", HospitalNumber = "001", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(2).ToShortDateString(), Drug = drug2, Doctor = doctorMurphy, Hospital = royalHealthCare };
var patient2 = new Patient() { Name = "Kate", Address = "No. 2 Ola street", RegistrationNumber = "2211", HospitalNumber = "002", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(1).ToShortDateString(), Drug = drug2, Doctor = doctorIfe, Hospital = royalHealthCare };
var patient3 = new Patient() { Name = "Sarah", Address = "No. 3 freeland street", RegistrationNumber = "22121", HospitalNumber = "003", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(5).ToShortDateString(), Drug = drug1, Doctor = doctorMark, Hospital = royalHealthCare };
var patient4 = new Patient() { Name = "Emma", Address = "No. 4 Tran street", RegistrationNumber = "22121", HospitalNumber = "004", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(2).ToShortDateString(), Drug = drug2, Doctor = doctorLucky, Hospital = royalHealthCare };
var patient5 = new Patient() { Name = "Kelvin", Address = "No. 5 kaka street", RegistrationNumber = "22121", HospitalNumber = "005", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(4).ToShortDateString(), Drug = drug1, Doctor = doctorVivian, Hospital = royalHealthCare };

var patient6 = new Patient() { Name = "James", Address = "No. 6 peace close", RegistrationNumber = "22121", HospitalNumber = "006", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(0).ToShortDateString(), Drug = drug4, Doctor = doctorMurphy, Hospital = royalHealthCare };
var patient7 = new Patient() { Name = "Irin", Address = "No. 7 Tran Layout", RegistrationNumber = "264651", HospitalNumber = "007", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(6).ToShortDateString(), Drug = drug5, Doctor = doctorIfe, Hospital = royalHealthCare };
var patient8 = new Patient() { Name = "Jax", Address = "No. 8 winner Layout", RegistrationNumber = "43421", HospitalNumber = "008", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(0).ToShortDateString(), Drug = drug6, Doctor = doctorMark, Hospital = royalHealthCare };
var patient9 = new Patient() { Name = "MArk", Address = "No. 9 lawa close", RegistrationNumber = "25251", HospitalNumber = "009", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(7).ToShortDateString(), Drug = drug10, Doctor = doctorLucky, Hospital = royalHealthCare };
var patient10 = new Patient() { Name = "Alex", Address = "No. 10 Tran close", RegistrationNumber = "252531", HospitalNumber = "010", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(3).ToShortDateString(), Drug = drug9, Doctor = doctorVivian, Hospital = royalHealthCare };

DataBaseManager.AddItem(patient1);
DataBaseManager.AddItem(patient2);
DataBaseManager.AddItem(patient3);
DataBaseManager.AddItem(patient4);
DataBaseManager.AddItem(patient5);
DataBaseManager.AddItem(patient6);
DataBaseManager.AddItem(patient7);
DataBaseManager.AddItem(patient8);
DataBaseManager.AddItem(patient9);
DataBaseManager.AddItem(patient10);



doctorMurphy = new Doctor() { Id = 1, Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state", Patient = patient1 };
DataBaseManager.UpdateItem(doctorMurphy);
doctorIfe = new Doctor() { Id = 2, Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH", Patient = patient2 };
DataBaseManager.UpdateItem(doctorIfe);
doctorMark = new Doctor() { Id = 3, Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH", Patient = patient3 };
DataBaseManager.UpdateItem(doctorMark);
doctorLucky = new Doctor() { Id = 4, Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH", Patient = patient4 };
DataBaseManager.UpdateItem(doctorLucky);
doctorVivian = new Doctor() { Id = 5, Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state", Patient = patient5 };
DataBaseManager.UpdateItem(doctorVivian);


doctorMurphy = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state", Patient = patient6 };
DataBaseManager.AddItem(doctorMurphy);
doctorIfe = new Doctor() { Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH", Patient = patient7 };
DataBaseManager.AddItem(doctorIfe);
doctorMark = new Doctor() { Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH", Patient = patient8 };
DataBaseManager.AddItem(doctorMark);
doctorLucky = new Doctor() { Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH", Patient = patient9 };
DataBaseManager.AddItem(doctorLucky);
doctorVivian = new Doctor() { Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state", Patient = patient10 };
DataBaseManager.AddItem(doctorVivian);



receptionistCollins = new Receptionist() { Id = 1, Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient1, Hospital = royalHealthCare };
DataBaseManager.UpdateItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient2, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient3, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient4, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient5, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient6, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient7, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient8, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient9, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient10, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);



//-------- Worked 1 Generic Get
//var items = DataBaseManager.ReadItem<Doctor>(1);
//Console.WriteLine($"{items.Id}, {items.Name}, {items.Address}");


// ------ worked 2 Generic query that takes the entityName as parameter
//var items = DataBaseManager.ReadItem<Receptionist>("Receptionist");
//foreach (var content in items)
//{
//    Console.WriteLine($"{content.Id}, {content.Name}, {content.Address}");
//}


// ------ worked 3 Generic query that takes no parameter
//var items = DataBaseManager.ReadItem<Doctor>();
//foreach (var content in items)
//{
//    Console.WriteLine($"{content.Id}, {content.Name}, {content.Address}");
//}




//             -------------------------IMPLEMENTING DATABASE QUERY---------------------------------


// Query 1:
Console.WriteLine(" Query 1\n");

// Takes the name of the doctor and appointment-date of the patients to query for all patients assigned to that doctor for that day
var seenDate = new DateTime(2022, 5, 30);
HospitalManager.ExstractAllDoctorsPatient("Murphy", seenDate);



// Query 2:
Console.WriteLine(" Query 2\n");



// Query 3:
Console.WriteLine(" Query 3\n");

// Displaces from the database a list of doctors working in the Hospital to the console
HospitalManager.AllDoctorsInHospital();



// Query 4:
Console.WriteLine(" Query 4\n");


// Displace from the database all patients in the hospital
HospitalManager.AllHospitalPatients();


// Query 5:
Console.WriteLine(" Query 5\n");

// Displace from the database all patients that are registered in the hospital
HospitalManager.AllRegisteredHospitalPatient();
// Displace from the database all patients that are unregistered in the hospital
HospitalManager.AllUnregisteredHospitalPatient();



// Query 6:
Console.WriteLine(" Query 6\n");

// Displace from the database all patients that are owing in the hospital
HospitalManager.AllOwingHospitalPatient();
// Displace from the database all patients that have paid in the hospital
HospitalManager.AllPaidHospitalPatient();



// Query 7:
Console.WriteLine(" Query 7\n");

// Displaces  top one most bought drug drug in the Database
HospitalManager.TopOneDrugsSales();

// Displaces a list of top ten most bought drugs in the Database
HospitalManager.TopTenDrugsSales();



// Query 8:
Console.WriteLine(" Query 8\n");

// Please Check DataBaseManager.cs file under helper folder
Console.WriteLine(" Please Check the DataBaseManager.cs file to access the Generic CRUD methods for our database. And HospitalManager.cs file for other methods \n");


// Query 9:
Console.WriteLine(" Query 9\n");
// Other Dataase query


// Displaces the most Expensive drug in the Database
HospitalManager.MostExpensiveDrugs();


// Filters Drugs database based on price
HospitalManager.DrugsPriceFilter(500m);


// This is to reset the Database
FluentNHibernateHelper.ResetSessionFactory();







/*
var myPatientList = new List<Patient> { };
myPatientList.Add(patient1);
myPatientList.Add(patient2);
myPatientList.Add(patient3);
myPatientList.Add(patient4);
myPatientList.Add(patient5);
myPatientList.Add(patient6);
myPatientList.Add(patient7);
myPatientList.Add(patient8);
myPatientList.Add(patient9);
myPatientList.Add(patient10);

foreach (var item in myPatientList)
{
    item.BookAppointment(item, item.Hospital);
    item.Register(item, item.Hospital);
    item.SeeTheDoctor(item, item.Hospital);
    Console.WriteLine("\n");
}
*/
