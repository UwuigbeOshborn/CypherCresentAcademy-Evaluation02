﻿// See https://aka.ms/new-console-template for more information
using OshbornCCSAevaluation2;
using OshbornCCSAevaluation2.Helpers;
using OshbornCCSAevaluation2.Models;

FluentNHibernateHelper.ResetSessionFactory();
FluentNHibernateHelper.OpenSession();

Console.WriteLine("Welcome to Oshborn's Hospital Management System!\n");


var royalHealthCare = new Hospital() { Name = "Royal Health Care", Address = "N0. 20 PTI road warri, Delta state." };
DataBaseManager.AddItem(royalHealthCare);

var receptionistCollins = new Receptionist() { Name = "Collins", Hospital = royalHealthCare, Address = "No. 13 Tunde street, Edo state" };
DataBaseManager.AddItem(receptionistCollins);

var pharmacistDavid = new Pharmacist() { Name = "David", Hospital = royalHealthCare, Address = "No. 13 ekewan street, Edo state" };
DataBaseManager.AddItem(pharmacistDavid);

var nurseJoseph = new Nurse() { Name = "Joseph", Hospital = royalHealthCare, Address = "No. 13 Bankole street, Abuja state" };
DataBaseManager.AddItem(nurseJoseph);


var accountantJude= new Accountant() { Name = "Jude", Hospital = royalHealthCare, Address = "No. 13 Ikeja street, Lagos state" };
DataBaseManager.AddItem(accountantJude);


var doctorMurphy = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state" };
var doctorIfe = new Doctor() { Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH" };
var doctorMark = new Doctor() { Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH" };
var doctorLucky = new Doctor() { Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH" };
var doctorVivian = new Doctor() { Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state" };
DataBaseManager.AddItem(doctorMurphy);
DataBaseManager.AddItem(doctorIfe);
DataBaseManager.AddItem(doctorMark);
DataBaseManager.AddItem(doctorLucky);
DataBaseManager.AddItem(doctorVivian);


var drug1 = new Drug() {Name = "Panadol", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 200m };
var drug2 = new Drug() { Name = "ProCold", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(-2).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 100m };
var drug3 = new Drug() { Name = "Vitamin C", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(-3).AddMonths(-7).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 500m };
var drug4 = new Drug() { Name = "Coartem", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(10).AddMonths(5).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 1500m };
var drug5 = new Drug() { Name = "Lunate DS", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(15).AddMonths(-4).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 800m };
var drug6 = new Drug() { Name = "Crestor", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(4).AddMonths(4).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 400m };
var drug7 = new Drug() { Name = "Amlodipine", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 2000m };
var drug8 = new Drug() { Name = "Ativan", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(22).AddMonths(7).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 2500m };
var drug9 = new Drug() { Name = "Morpine", Model = "2022/dddxxx321", ProductionDate = DateTime.Now.AddDays(-5).AddMonths(-5).AddYears(0).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(0).AddMonths(0).AddYears(2).ToShortDateString(), Cost = 300m };
var drug10 = new Drug() { Name = "Tramadol", Model = "2020/qw3xx111", ProductionDate = DateTime.Now.AddDays(2).AddMonths(10).AddYears(-1).ToShortDateString(), ExpiringDate = DateTime.Now.AddDays(2).AddMonths(1).AddYears(1).ToShortDateString(), Cost = 2000m };

DataBaseManager.AddItem(drug1);
DataBaseManager.AddItem(drug2);
DataBaseManager.AddItem(drug3);
DataBaseManager.AddItem(drug4);
DataBaseManager.AddItem(drug5);
DataBaseManager.AddItem(drug6);
DataBaseManager.AddItem(drug7);
DataBaseManager.AddItem(drug8);
DataBaseManager.AddItem(drug9);
DataBaseManager.AddItem(drug10);

//new IList<Drug>(){ drug2 }
var drugList = new List<Drug>() { };
//dg = new IList<Drug>() { drug2 };
//Drugs = drugList.Add(drug2)//var drugList = new List<Drug>() { drug1 };
var patient1 = new Patient() { Name = "John", Address = "No. 1 Tran Amadi", RegistrationNumber = "2231", HospitalNumber = "001", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(2).ToShortDateString(), Drugs = drugList, Doctor = doctorMurphy, Hospital = royalHealthCare };
var patient2 = new Patient() { Name = "Kate", Address = "No. 2 Ola street", RegistrationNumber = "2211", HospitalNumber = "002", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(1).ToShortDateString(), Drugs = drugList, Doctor = doctorIfe, Hospital = royalHealthCare };
var patient3 = new Patient() { Name = "Sarah", Address = "No. 3 freeland street", RegistrationNumber = "22121", HospitalNumber = "003", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(5).ToShortDateString(), Drugs = drugList, Doctor = doctorMark, Hospital = royalHealthCare };
var patient4 = new Patient() { Name = "Emma", Address = "No. 4 Tran street", RegistrationNumber = "22121", HospitalNumber = "004", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(2).ToShortDateString(), Drugs = drugList, Doctor = doctorLucky, Hospital = royalHealthCare };
var patient5 = new Patient() { Name = "Kelvin", Address = "No. 5 kaka street", RegistrationNumber = "22121", HospitalNumber = "005", RegistrationStatus = Registration_Status.Registered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(4).ToShortDateString(), Drugs = drugList, Doctor = doctorVivian, Hospital = royalHealthCare };

var patient6 = new Patient() { Name = "James", Address = "No. 6 peace close", RegistrationNumber = "22121", HospitalNumber = "006", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(0).ToShortDateString(), Drugs = drugList, Doctor = doctorMurphy, Hospital = royalHealthCare };
var patient7 = new Patient() { Name = "Irin", Address = "No. 7 Tran Layout", RegistrationNumber = "264651", HospitalNumber = "007", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(6).ToShortDateString(), Drugs = drugList, Doctor = doctorIfe, Hospital = royalHealthCare };
var patient8 = new Patient() { Name = "Jax", Address = "No. 8 winner Layout", RegistrationNumber = "43421", HospitalNumber = "008", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(0).ToShortDateString(), Drugs = drugList, Doctor = doctorMark, Hospital = royalHealthCare };
var patient9 = new Patient() { Name = "MArk", Address = "No. 9 lawa close", RegistrationNumber = "25251", HospitalNumber = "009", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Paid.ToString(), BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), AppointmentDate = DateTime.Now.AddDays(7).ToShortDateString(), Drugs = drugList, Doctor = doctorLucky, Hospital = royalHealthCare };
var patient10 = new Patient() { Name = "Alex", Address = "No. 10 Tran close", RegistrationNumber = "252531", HospitalNumber = "010", RegistrationStatus = Registration_Status.Unregistered.ToString(), PaymentStatus = Payment_Status.Owing.ToString(), BookAppointmentStatus = BookAppointment_Status.NoBooking.ToString(), AppointmentDate = DateTime.Now.AddDays(3).ToShortDateString(), Drugs = drugList, Doctor = doctorVivian, Hospital = royalHealthCare };

DataBaseManager.AddItem(patient1);
DataBaseManager.AddItem(patient2);
DataBaseManager.AddItem(patient3);
DataBaseManager.AddItem(patient4);
DataBaseManager.AddItem(patient5);
DataBaseManager.AddItem(patient6);
DataBaseManager.AddItem(patient7);
DataBaseManager.AddItem(patient8);
DataBaseManager.AddItem(patient9);
DataBaseManager.AddItem(patient10);



doctorMurphy = new Doctor() { Id = 1, Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state", Patient = patient1 };
DataBaseManager.UpdateItem(doctorMurphy);
doctorIfe = new Doctor() { Id = 2, Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH", Patient = patient2 };
DataBaseManager.UpdateItem(doctorIfe);
doctorMark = new Doctor() { Id = 3, Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH", Patient = patient3 };
DataBaseManager.UpdateItem(doctorMark);
doctorLucky = new Doctor() { Id = 4, Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH", Patient = patient4 };
DataBaseManager.UpdateItem(doctorLucky);
doctorVivian = new Doctor() { Id = 5, Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state", Patient = patient5 };
DataBaseManager.UpdateItem(doctorVivian);


doctorMurphy = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state", Patient = patient6 };
DataBaseManager.AddItem(doctorMurphy);
doctorIfe = new Doctor() { Name = "Ife", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH", Patient = patient7 };
DataBaseManager.AddItem(doctorIfe);
doctorMark = new Doctor() { Name = "Mark", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH", Patient = patient8 };
DataBaseManager.AddItem(doctorMark);
doctorLucky = new Doctor() { Name = "Lucky", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH", Patient = patient9 };
DataBaseManager.AddItem(doctorLucky);
doctorVivian = new Doctor() { Name = "Vivian", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state", Patient = patient10 };
DataBaseManager.AddItem(doctorVivian);



receptionistCollins = new Receptionist() { Id = 1, Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient1, Hospital = royalHealthCare };
DataBaseManager.UpdateItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient2, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient3, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient4, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient5, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient6, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient7, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient8, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient9, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);
receptionistCollins = new Receptionist() { Name = "Collins", Address = "No. 13 Tunde street, Edo state", Patient = patient10, Hospital = royalHealthCare };
DataBaseManager.AddItem(receptionistCollins);


pharmacistDavid = new Pharmacist() { Id = 1, Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient1, Hospital = royalHealthCare };
DataBaseManager.UpdateItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient2, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient3, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient4, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient5, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient6, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient7, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient8, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient9, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);
pharmacistDavid = new Pharmacist() { Name = "David", Address = "No. 13 ekewan street, Edo state", Patient = patient10, Hospital = royalHealthCare };
DataBaseManager.AddItem(pharmacistDavid);


nurseJoseph = new Nurse() { Id = 1, Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient1, Hospital = royalHealthCare };
DataBaseManager.UpdateItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient2, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient3, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient4, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient5, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient6, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient7, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient8, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient9, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);
nurseJoseph = new Nurse() { Name = "Joseph", Address = "No. 13 Bankole street, Abuja state", Patient = patient10, Hospital = royalHealthCare };
DataBaseManager.AddItem(nurseJoseph);




accountantJude = new Accountant() { Id = 1, Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient1, Hospital = royalHealthCare };
DataBaseManager.UpdateItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient2, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient3, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient4, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient5, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient6, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient7, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient8, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient9, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);
accountantJude = new Accountant() { Name = "Jude", Address = "No. 13 Ikeja street, Lagos state", Patient = patient10, Hospital = royalHealthCare };
DataBaseManager.AddItem(accountantJude);


//-------- Worked 1 Generic Get
//var items = DataBaseManager.ReadItem<Doctor>(1);
//Console.WriteLine($"{items.Id}, {items.Name}, {items.Address}");


// ------ worked 2 Generic query that takes the entityName as parameter
//var items = DataBaseManager.ReadItem<Receptionist>("Receptionist");
//foreach (var content in items)
//{
//    Console.WriteLine($"{content.Id}, {content.Name}, {content.Address}");
//}


// ------ worked 3 Generic query that takes no parameter
//var items = DataBaseManager.ReadItem<Doctor>();
//foreach (var content in items)
//{
//    Console.WriteLine($"{content.Id}, {content.Name}, {content.Address}");
//}



//             -------------------------IMPLEMENTING DATABASE QUERY---------------------------------


// Query 1:
Console.WriteLine(" Query 1\n");

// Takes the name of the doctor and appointment-date of the patients to query for all patients assigned to that doctor for that day
var seenDate = new DateTime(2022, 5, 30);
HospitalManager.ExstractAllDoctorsPatientWithDate("Murphy", seenDate);



// Query 2:
Console.WriteLine(" Query 2\n");



// Query 3:
Console.WriteLine(" Query 3\n");

// Displaces from the database a list of doctors working in the Hospital to the console
HospitalManager.AllDoctorsInHospital();



// Query 4:
Console.WriteLine(" Query 4\n");


// Displace from the database all patients in the hospital
HospitalManager.AllHospitalPatients();


// Query 5:
Console.WriteLine(" Query 5\n");

// Displace from the database all patients that are registered in the hospital
HospitalManager.AllRegisteredHospitalPatient();
// Displace from the database all patients that are unregistered in the hospital
HospitalManager.AllUnregisteredHospitalPatient();



// Query 6:
Console.WriteLine(" Query 6\n");

// Displace from the database all patients that are owing in the hospital
HospitalManager.AllOwingHospitalPatient();
// Displace from the database all patients that have paid in the hospital
HospitalManager.AllPaidHospitalPatient();



// Query 7:
Console.WriteLine(" Query 7\n");

// Displaces  top one most bought drug drug in the Database
HospitalManager.TopOneDrugsSales();

// Displaces a list of top ten most bought drugs in the Database
HospitalManager.TopTenDrugsSales();



// Query 8:
Console.WriteLine(" Query 8\n");

// Please Check DataBaseManager.cs file under helper folder
Console.WriteLine(" Please Check the DataBaseManager.cs file to access the Generic CRUD methods for our database. And HospitalManager.cs file for other methods \n");


// Query 9:
Console.WriteLine(" Query 9 and Others\n");
// Other Dataase query


// Displaces the most Expensive drug in the Database
HospitalManager.MostExpensiveDrugs();


// Filters Drugs database based on price
HospitalManager.DrugsPriceFilter(500m);


// This is to reset the Database
FluentNHibernateHelper.ResetSessionFactory();


/*
var myPatientList = new List<Patient> { };
myPatientList.Add(patient1);
myPatientList.Add(patient2);
myPatientList.Add(patient3);
myPatientList.Add(patient4);
myPatientList.Add(patient5);
myPatientList.Add(patient6);
myPatientList.Add(patient7);
myPatientList.Add(patient8);
myPatientList.Add(patient9);
myPatientList.Add(patient10);

foreach (var item in myPatientList)
{
    item.BookAppointment(item, item.Hospital);
    item.Register(item, item.Hospital);
    item.SeeTheDoctor(item, item.Hospital);
    Console.WriteLine("\n");
}
*/






//    - ----------------------------------------------------------------  Below programs entails uses console interactive section.    Try it out it's  beautiful------------------------------------------





int count, count2, count3;
string username, selectedOption, selectedOption2, selectedOption3, selectedOption4, selectedOption5, selectedOption6, selectedOption7, selectedOption8, selectedOption9, selectedOption10, selectedOption11, selectedOption12, selectedOption13, selectedOption14, selectedOption15, selectedOption16;

Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
Console.Write("            ********************    WELCOME TO HOSPITAL DATABASE MANAGEMENT SYSTEM    ********************\n");
Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");

Console.Write("Please enter Username: ");
username = Convert.ToString(Console.ReadLine());

count = 0;
while (count < 5)
{
    Console.Write("\n\nHello {0} would you like to;\n\n", username);
    Console.Write("1.) Access patient's portal? if yes enter 1\n");
    Console.Write("2.) Access doctor's portal? if yes enter 2\n");
    Console.Write("3.) Access receptionist's portal? if yes enter 3\n");
    Console.Write("4.) Access nurse's portal? if yes enter 4\n");
    Console.Write("5.) Access pharmacist's portal? if yes enter 5\n");
    Console.Write("6.) Access accountant's portal? if yes enter 6\n");
    Console.Write("7.) Access existing database? if yes enter 7\n");
    Console.Write("8.) Make changes on existing database? if yes enter 8\n");
    Console.Write("9.) Reset existing database? if yes enter 9\n");
    Console.Write("                   Else, enter NO\n");
    Console.Write("\nPlease choose: ");
    selectedOption = Convert.ToString(Console.ReadLine());

    if (selectedOption != "1" && selectedOption != "2" && selectedOption != "3" && selectedOption != "4" && selectedOption != "5" && selectedOption != "6" && selectedOption != "7" && selectedOption != "8" && selectedOption != "9" && selectedOption != "NO")
    {
        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
        Console.Write("Would you like to try again? YES or NO: ");
        selectedOption2 = Convert.ToString(Console.ReadLine());
        if (selectedOption2 == "YES")
        {
            count += 1;
        }
        else if (selectedOption2 == "NO")
        {
            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
            break;
        }
        else
        {
            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
            break;
        }
    }

    if (selectedOption == "NO")
    {
        break;
    }


    if (selectedOption == "1")
    {
        count2 = 0;
        while (count2 < 5)
        {
            Console.Write("----------------------------------------------------------------------------------------------------------------------------\n");
            Console.Write("                                  **********       Accessing Patient's Portal      **********\n");
            Console.Write("----------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.Write("\n\nHello {0} would you like to;\n\n", username);
            Console.Write("1.) Register? if yes enter 1\n");
            Console.Write("2.) See the doctor? if yes enter 2\n");
            Console.Write("3.) Book appointment? if yes enter 3\n");
            Console.Write("4.) Make payment? if yes enter 4\n");
            Console.Write("         Else, enter NO\n");
            Console.Write("\nPlease choose: ");
            selectedOption3 = Convert.ToString(Console.ReadLine());

            if (selectedOption3 != "1" && selectedOption3 != "2" && selectedOption3 != "3" && selectedOption3 != "4" && selectedOption3 != "5" && selectedOption3 != "NO")
            {
                Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                Console.Write("Would you like to try again? YES or NO: ");
                selectedOption4 = Convert.ToString(Console.ReadLine());
                if (selectedOption4 == "YES")
                {
                    count2 += 1;
                }
                else if (selectedOption4 == "NO")
                {
                    Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                    break;
                }
                else
                {
                    Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                    break;
                }
            }

            if (selectedOption3 == "NO")
            {
                break;
            }

            if (selectedOption3 == "1")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Registering patient        **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");

                    Console.Write("\n\nEnter patient's name: ");
                    string patientName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's address: ");
                    string patienAddress = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's phone number: ");
                    string patientPhoneNumber = Convert.ToString(Console.ReadLine());

                    var newPatient = new Patient() { Name = patientName, Address = patienAddress, PhoneNumber = patientPhoneNumber };
                    HospitalManager.RegisterPatient(newPatient, royalHealthCare);
                    break;
                }
            }

            if (selectedOption3 == "2")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********         Seeing the doctor     **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");

                    Console.Write("\nEnter patient's hospital number: ");
                    string patientHospitalNumber = Convert.ToString(Console.ReadLine());

                    HospitalManager.SeeTheDoctorApproval(patientHospitalNumber, royalHealthCare);
                    break;
                }
            }
            if (selectedOption3 == "3")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Booking appointment with a doctor      **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");

                    Console.Write("\n\nEnter patient's name: ");
                    string patientName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's address: ");
                    string patienAddress = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's phone number: ");
                    string patientPhoneNumber = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter your registration number to enjoy discount: ");
                    string patientRegistrationNumber = Convert.ToString(Console.ReadLine());

                    HospitalManager.BookAppointment(patientRegistrationNumber, royalHealthCare, patientName, patienAddress, patientPhoneNumber);
                    break;
                }
            }
            if (selectedOption3 == "4")
            {
                // not ready yet
                break;
            }
        }
    }

    if (selectedOption == "2")
    {
        count2 = 0;
        while (count2 < 5)
        {
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n");
            Console.Write("                          **********       Accessing Doctor's Portal       **********\n");
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.Write("\n\nHello {0} would you like to;\n\n", username);
            Console.Write("1.) Check for scheduled patients? if yes enter 1\n");
            Console.Write("2.) Adminstration/Prescription of drugs to patients? if yes enter 2\n");
            Console.Write("3.) Check patients medical condition? if yes enter 3\n");
            Console.Write("                  Else, enter NO\n");
            Console.Write("\nPlease choose: ");
            selectedOption5 = Convert.ToString(Console.ReadLine());

            if (selectedOption5 != "1" && selectedOption5 != "2" && selectedOption5 != "3" && selectedOption5 != "NO")
            {
                Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                Console.Write("Would you like to try again? YES or NO: ");
                selectedOption6 = Convert.ToString(Console.ReadLine());
                if (selectedOption6 == "YES")
                {
                    count2 += 1;
                }
                else if (selectedOption6 == "NO")
                {
                    Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                    break;
                }
                else
                {
                    Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                    break;
                }
            }

            if (selectedOption5 == "NO")
            {
                break;
            }


            if (selectedOption5 == "1")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Checking for doctor's scheduled patients database       **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Check for all scheduled patients to a doctor? if yes enter 1\n");
                    Console.Write("2.) Check for scheduled patients with appointment date? if yes enter 2\n");
                    Console.Write("                Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count2 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    if (selectedOption7 == "NO")
                    {
                        break;
                    }


                    if (selectedOption7 == "1")
                    {
                        Console.Write("\nEnter doctor's name: ");
                        string doctorName = Convert.ToString(Console.ReadLine());

                        // Takes the name of the doctor to query for all patients assigned to that doctor regardless of date
                        HospitalManager.ExstractAllDoctorsPatient(doctorName);
                        break;
                    }
                    if (selectedOption7 == "2")
                    {
                        Console.Write("\nEnter doctor's name: ");
                        string doctorName = Convert.ToString(Console.ReadLine());
                        Console.Write("\nEnter patient's appointment date E.g(int year, int month, int day): ");
                        DateTime appointmentdate = Convert.ToDateTime(Console.ReadLine());

                        // Takes the name of the doctor and appointment-date of the patients to query for all patients assigned to that doctor for that day
                        HospitalManager.ExstractAllDoctorsPatientWithDate(doctorName, appointmentdate);
                        break;
                    }
                }
            }

            if (selectedOption5 == "2")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Adminstration/Prescription of drugs to patients      **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");

                    Console.Write("\nEnter doctor's name: ");
                    string doctorName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's name: ");
                    string patientName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's hospital number: ");
                    string patientHospitalNumber = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's appointment date E.g(int year, int month, int day): ");
                    DateTime patientAppointmentdate = Convert.ToDateTime(Console.ReadLine());

                    Console.Write("\n\n Hello {0}, please select drug to be adminitered;\n\n", doctorName);
                    Console.Write("1.) Panadol? if yes enter 1\n");
                    Console.Write("2.) Procold? if yes enter 2\n");
                    Console.Write("3.) Vitamin C? if yes enter 3\n");
                    Console.Write("4.) Coartem? if yes enter 4\n");
                    Console.Write("5.) Lunate_DS? if yes enter 5\n");
                    Console.Write("6.) Crestor? if yes enter 6\n");
                    Console.Write("7.) Amlodipine? if yes enter 7\n");
                    Console.Write("8.) Ativan? if yes enter 8\n");
                    Console.Write("9.) Morpine? if yes enter 9\n");
                    Console.Write("10.) Tramadol? if yes enter 10\n");
                    Console.Write("         Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption9 = Convert.ToString(Console.ReadLine());
                    if (selectedOption9 != "1" && selectedOption9 != "2" && selectedOption9 != "3" && selectedOption9 != "4" && selectedOption9 != "5" && selectedOption9 != "6" && selectedOption9 != "7" && selectedOption9 != "8" && selectedOption9 != "9" && selectedOption9 != "10" && selectedOption9 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption10 = Convert.ToString(Console.ReadLine());
                        if (selectedOption10 == "YES")
                        {
                            count2 += 1;
                        }
                        else if (selectedOption10 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    if (selectedOption9 == "NO")
                    {
                        break;
                    }
                    else
                    {
                        int adminiteredDrugId = Convert.ToInt32(selectedOption9);
                        var getDrug = DataBaseManager.ReadItem<Drug>(adminiteredDrugId);
                        // Takes the name of the doctor and appointment-date of the patients to query for all patients assigned to that doctor for that day
                        HospitalManager.AdminiterDrug(doctorName, patientName, patientHospitalNumber, patientAppointmentdate, getDrug);
                        break;
                    }
                }
            }
            if (selectedOption5 == "3")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Checking patients medical condition       **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Have conversation with patient? if yes enter 1\n");
                    Console.Write("2.) Run a test? if yes enter 2\n");
                    Console.Write("3.) Run a scan? if yes enter 3\n");
                    Console.Write("4.) Check patient medical history? if yes enter 4\n");
                    Console.Write("                 Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption11 = Convert.ToString(Console.ReadLine());

                    if (selectedOption11 != "1" && selectedOption11 != "2" && selectedOption11 != "3" && selectedOption11 != "4" && selectedOption11 != "5" && selectedOption11 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption12 = Convert.ToString(Console.ReadLine());
                        if (selectedOption12 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption12 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }


                    if (selectedOption11 == "NO")
                    {
                        break;
                    }

                    if (selectedOption11 == "1")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.AddItem(student);
                        break;
                    }

                    if (selectedOption11 == "2")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.ReadItem(student);
                        break;
                    }

                    if (selectedOption11 == "3")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.UpdateItem(student);
                        break;
                    }

                    if (selectedOption11 == "4")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.DeleteItem(student);
                        break;
                    }
                }
            }
        }
    }
    if (selectedOption == "3")
    {
        count2 = 0;
        while (count2 < 5)
        {
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n");
            Console.Write("                          **********       Accessing Receptionist's Portal       **********\n");
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.Write("\n\nHello {0} would you like to;\n\n", username);
            Console.Write("1.) Register a patient? if yes enter 1\n");
            Console.Write("2.) Book appointment for patient? if yes enter 2\n");
            Console.Write("3.) Grant patient approval to see the doctor? if yes enter 2\n");
            Console.Write("                  Else, enter NO\n");
            Console.Write("\nPlease choose: ");
            selectedOption13 = Convert.ToString(Console.ReadLine());

            if (selectedOption13 != "1" && selectedOption13 != "2" && selectedOption13 != "3" && selectedOption13 != "NO")
            {
                Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                Console.Write("Would you like to try again? YES or NO: ");
                selectedOption14 = Convert.ToString(Console.ReadLine());
                if (selectedOption14 == "YES")
                {
                    count2 += 1;
                }
                else if (selectedOption14 == "NO")
                {
                    Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                    break;
                }
                else
                {
                    Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                    break;
                }
            }

            if (selectedOption13 == "NO")
            {
                break;
            }


            if (selectedOption13 == "1")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Registering patient        **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");
                    
                    Console.Write("\n\nEnter patient's name: ");
                    string patientName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's address: ");
                    string patienAddress = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's phone number: ");
                    string patientPhoneNumber = Convert.ToString(Console.ReadLine());

                    var newPatient = new Patient() { Name = patientName, Address = patienAddress, PhoneNumber = patientPhoneNumber };
                    HospitalManager.RegisterPatient(newPatient, royalHealthCare);
                    break;
                }
            }

            if (selectedOption13 == "2")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Booking appointment for patient      **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");

                    Console.Write("\n\nEnter patient's name: ");
                    string patientName = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's address: ");
                    string patienAddress = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter patient's phone number: ");
                    string patientPhoneNumber = Convert.ToString(Console.ReadLine());
                    Console.Write("\nEnter your registration number to enjoy discount: ");
                    string patientRegistrationNumber = Convert.ToString(Console.ReadLine());

                    HospitalManager.BookAppointment(patientRegistrationNumber, royalHealthCare, patientName, patienAddress, patientPhoneNumber);
                    break;
                }
            }
            if (selectedOption13 == "3")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Granting patient approval to see the doctor       **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");
                    
                    Console.Write("\nEnter patient's hospital number: ");
                    string patientHospitalNumber = Convert.ToString(Console.ReadLine());

                    HospitalManager.SeeTheDoctorApproval(patientHospitalNumber, royalHealthCare);
                    break;
                }
            }
        }
    }
    // To be continued => Check point
    if (selectedOption == "7")
    {
        count2 = 0;
        while (count2 < 5)
        {
            Console.Write("----------------------------------------------------------------------------------------------------------------------------\n");
            Console.Write("                                  **********       Accessing existing database       **********\n");
            Console.Write("----------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.Write("\n\nHello {0} would you like to;\n\n", username);
            Console.Write("1.) Access all database info? if yes enter 1\n");
            Console.Write("                Else, enter NO\n");
            Console.Write("\nPlease choose: ");
            selectedOption3 = Convert.ToString(Console.ReadLine());

            if (selectedOption3 != "1" && selectedOption3 != "2" && selectedOption3 != "3" && selectedOption3 != "4" && selectedOption3 != "5" && selectedOption3 != "NO")
            {
                Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                Console.Write("Would you like to try again? YES or NO: ");
                selectedOption4 = Convert.ToString(Console.ReadLine());
                if (selectedOption4 == "YES")
                {
                    count2 += 1;
                }
                else if (selectedOption4 == "NO")
                {
                    Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                    break;
                }
                else
                {
                    Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                    break;
                }
            }

            if (selectedOption3 == "NO")
            {
                break;
            }

            if (selectedOption3 == "1")
            {
                //Console.Write("\nEnter school Id: ");
                //int id = Convert.ToInt32(Console.ReadLine());
                //Console.Write("\nEnter school name: ");
                //string name = Convert.ToString(Console.ReadLine());
                //Console.Write("\nEnter school address: ");
                //string address = Convert.ToString(Console.ReadLine());

                //var school = new School() { Id = id, Name = name, Address = address };
                //FluentNHibernateHelper.ReadItem(school);

                //Console.Write("\nEnter student Id: ");
                //int id = Convert.ToInt32(Console.ReadLine());
                //Console.Write("\nEnter student fullame: ");
                //string fullName = Convert.ToString(Console.ReadLine());
                //Console.Write("\nEnter student school name: ");
                //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                //Console.Write("\nEnter student assigned classroom name: ");
                //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                //var teacher = new Teacher() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                //FluentNHibernateHelper.ReadItem(teacher);

                //Console.Write("\nEnter student Id: ");
                //int id = Convert.ToInt32(Console.ReadLine());
                //Console.Write("\nEnter student fullame: ");
                //string fullName = Convert.ToString(Console.ReadLine());
                //Console.Write("\nEnter student school name: ");
                //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                //Console.Write("\nEnter student assigned classroom name: ");
                //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                //FluentNHibernateHelper.ReadItem(student);

                //Console.Write("\nEnter clasroom Id: ");
                //int id = Convert.ToInt32(Console.ReadLine());
                //Console.Write("\nEnter clasroom name: ");
                //string name = Convert.ToString(Console.ReadLine());

                //var subject = new Subject() { Id = id, Name = name };
                //FluentNHibernateHelper.ReadItem(subject);

                //Console.Write("\nEnter clasroom Id: ");
                //int id = Convert.ToInt32(Console.ReadLine());
                //Console.Write("\nEnter clasroom name: ");
                //string name = Convert.ToString(Console.ReadLine());
                //Console.Write("\nEnter school name: ");
                //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                //Console.Write("\nEnter teacher(incharge of class) fullname: ");
                //Teacher teacher = new Teacher() { FullName = Convert.ToString(Console.ReadLine()) };

                //var classRoom = new ClassRoom() { Id = id, Name = name, School = school, Teacher = teacher };
                //FluentNHibernateHelper.ReadItem(classRoom);


                break;
            }
        }
    }

    if (selectedOption == "8")
    {
        count2 = 0;
        while (count2 < 5)
        {
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n");
            Console.Write("                          **********       Make changes on existing database       **********\n");
            Console.Write("-----------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.Write("\n\nHello {0} would you like to;\n\n", username);
            Console.Write("1.) Make changes on patient's database? if yes enter 1\n");
            Console.Write("2.) Make changes on doctor's database? if yes enter 2\n");
            Console.Write("3.) Make changes on drug's database? if yes enter 3\n");
            Console.Write("4.) Make changes on receptionist's database? if yes enter 4\n");
            Console.Write("5.) Make changes on hospital's database? if yes enter 5\n");
            Console.Write("                 Else, enter NO\n");
            Console.Write("\nPlease choose: ");
            selectedOption5 = Convert.ToString(Console.ReadLine());

            if (selectedOption5 != "1" && selectedOption5 != "2" && selectedOption5 != "3" && selectedOption5 != "4" && selectedOption5 != "5" && selectedOption5 != "NO")
            {
                Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                Console.Write("Would you like to try again? YES or NO: ");
                selectedOption6 = Convert.ToString(Console.ReadLine());
                if (selectedOption6 == "YES")
                {
                    count2 += 1;
                }
                else if (selectedOption6 == "NO")
                {
                    Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                    break;
                }
                else
                {
                    Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                    break;
                }
            }

            if (selectedOption5 == "NO")
            {
                break;
            }


            if (selectedOption5 == "1")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********       Make changes on existing patient's database       **********\n");
                    Console.Write("---------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Create new patient row? if yes enter 1\n");
                    Console.Write("2.) Read patient row? if yes enter 2\n");
                    Console.Write("3.) Update patient row? if yes enter 3\n");
                    Console.Write("4.) Delete patient row? if yes enter 4\n");
                    Console.Write("                      Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "3" && selectedOption7 != "4" && selectedOption7 != "5" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    
                    if (selectedOption7 == "NO")
                    {
                        break;
                    }

                    if (selectedOption7 == "1")
                    {
                        //Console.Write("\nEnter school Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school address: ");
                        //string address = Convert.ToString(Console.ReadLine());

                        //var school = new School() { Id = id, Name = name, Address = address };
                        //FluentNHibernateHelper.AddItem(school);
                        break;
                    }

                    if (selectedOption7 == "2")
                    {
                        //Console.Write("\nEnter school Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school address: ");
                        //string address = Convert.ToString(Console.ReadLine());

                        //var school = new School() { Id = id, Name = name, Address = address };
                        //FluentNHibernateHelper.ReadItem(school.Id, school);
                        break;
                    }

                    if (selectedOption7 == "3")
                    {
                        //Console.Write("\nEnter school Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school address: ");
                        //string address = Convert.ToString(Console.ReadLine());

                        //var school = new School() { Id = id, Name = name, Address = address };
                        //FluentNHibernateHelper.UpdateItem(school);
                        break;
                    }

                    if (selectedOption7 == "4")
                    {
                        //Console.Write("\nEnter school Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school address: ");
                        //string address = Convert.ToString(Console.ReadLine());

                        //var school = new School() { Id = id, Name = name, Address = address };
                        //FluentNHibernateHelper.DeleteItem(school);
                        break;
                    }
                }
            }

            if (selectedOption5 == "2")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("----------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Make changes on existing doctor's database       **********\n");
                    Console.Write("----------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Create new doctor row? if yes enter 1\n");
                    Console.Write("2.) Read doctor row? if yes enter 2\n");
                    Console.Write("3.) Update doctor row? if yes enter 3\n");
                    Console.Write("4.) Delete doctor row? if yes enter 4\n");
                    Console.Write("            Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "3" && selectedOption7 != "4" && selectedOption7 != "5" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    
                    if (selectedOption7 == "NO")
                    {
                        break;
                    }

                    if (selectedOption7 == "1")
                    {
                        //Console.Write("\nEnter teacher Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter teacher fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter teacher school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var teacher = new Teacher() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.AddItem(teacher);
                        break;
                    }

                    if (selectedOption7 == "2")
                    {
                        //Console.Write("\nEnter teacher Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter teacher fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter teacher school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var teacher = new Teacher() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.ReadItem(teacher);
                        break;
                    }

                    if (selectedOption7 == "3")
                    {
                        //Console.Write("\nEnter teacher Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter teacher fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter teacher school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var teacher = new Teacher() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.UpdateItem(teacher);
                        break;
                    }

                    if (selectedOption7 == "4")
                    {
                        //Console.Write("\nEnter teacher Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter teacher fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter teacher school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var teacher = new Teacher() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.DeleteItem(teacher);
                        break;
                    }
                }
            }

            if (selectedOption5 == "3")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Make changes on existing drug's database      **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Create new drug row? if yes enter 1\n");
                    Console.Write("2.) Read drug row? if yes enter 2\n");
                    Console.Write("3.) Update drug row? if yes enter 3\n");
                    Console.Write("4.) Delete drug row? if yes enter 4\n");
                    Console.Write("             Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "3" && selectedOption7 != "4" && selectedOption7 != "5" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    
                    if (selectedOption7 == "NO")
                    {
                        break;
                    }

                    if (selectedOption7 == "1")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.AddItem(student);
                        break;
                    }

                    if (selectedOption7 == "2")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.ReadItem(student);
                        break;
                    }

                    if (selectedOption7 == "3")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.UpdateItem(student);
                        break;
                    }

                    if (selectedOption7 == "4")
                    {
                        //Console.Write("\nEnter student Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter student fullame: ");
                        //string fullName = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter student school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter student assigned classroom name: ");
                        //ClassRoom classroom = new ClassRoom() { Name = Convert.ToString(Console.ReadLine()) };

                        //var student = new Student() { Id = id, FullName = fullName, School = school, ClassRoom = classroom };
                        //FluentNHibernateHelper.DeleteItem(student);
                        break;
                    }
                }
            }

            if (selectedOption5 == "4")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Make changes on existing receptionist's database        **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Create new receptionist row? if yes enter 1\n");
                    Console.Write("2.) Read receptionist row? if yes enter 2\n");
                    Console.Write("3.) Update receptionist row? if yes enter 3\n");
                    Console.Write("4.) Delete receptionist row? if yes enter 4\n");
                    Console.Write("               Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "3" && selectedOption7 != "4" && selectedOption7 != "5" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    
                    if (selectedOption7 == "NO")
                    {
                        break;
                    }

                    if (selectedOption7 == "1")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());

                        //var subject = new Subject() { Id = id, Name = name};
                        //FluentNHibernateHelper.AddItem(subject);
                        break;
                    }

                    if (selectedOption7 == "2")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());

                        //var subject = new Subject() { Id = id, Name = name};
                        //FluentNHibernateHelper.ReadItem(subject);
                        break;
                    }

                    if (selectedOption7 == "3")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());

                        //var subject = new Subject() { Id = id, Name = name};
                        //FluentNHibernateHelper.UpdateItem(subject);
                        break;
                    }

                    if (selectedOption7 == "4")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());

                        //var subject = new Subject() { Id = id, Name = name};
                        //FluentNHibernateHelper.DeleteItem(subject);
                        break;
                    }
                }
            }

            if (selectedOption5 == "5")
            {
                count3 = 0;
                while (count3 < 5)
                {
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n");
                    Console.Write("                                  **********        Make changes on existing hospital's database        **********\n");
                    Console.Write("--------------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.Write("\n\nHello {0} would you like to;\n\n", username);
                    Console.Write("1.) Create new hospital row? if yes enter 1\n");
                    Console.Write("2.) Read hospital row? if yes enter 2\n");
                    Console.Write("3.) Update hospital row? if yes enter 3\n");
                    Console.Write("4.) Delete hospital row? if yes enter 4\n");
                    Console.Write("            Else, enter NO\n");
                    Console.Write("\nPlease choose: ");
                    selectedOption7 = Convert.ToString(Console.ReadLine());

                    if (selectedOption7 != "1" && selectedOption7 != "2" && selectedOption7 != "3" && selectedOption7 != "4" && selectedOption7 != "5" && selectedOption7 != "NO")
                    {
                        Console.Write("\n\nOops! {0} it seems you entered a wrong option;\n", username);
                        Console.Write("Would you like to try again? YES or NO: ");
                        selectedOption8 = Convert.ToString(Console.ReadLine());
                        if (selectedOption8 == "YES")
                        {
                            count3 += 1;
                        }
                        else if (selectedOption8 == "NO")
                        {
                            Console.Write("\n\nOkay, goodbye {0}, we will see another time;\n", username);
                            break;
                        }
                        else
                        {
                            Console.Write("\n\nOops! {0} it seems you entered a wrong option again. Goodbye;\n", username);
                            break;
                        }
                    }

                    
                    if (selectedOption7 == "NO")
                    {
                        break;
                    }

                    if (selectedOption7 == "1")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher(incharge of class) fullname: ");
                        //Teacher teacher = new Teacher() { FullName = Convert.ToString(Console.ReadLine()) };

                        //var classRoom = new ClassRoom() { Id = id, Name = name, School = school, Teacher = teacher };
                        //FluentNHibernateHelper.AddItem(classRoom);
                        break;
                    }

                    if (selectedOption7 == "2")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher(incharge of class) fullname: ");
                        //Teacher teacher = new Teacher() { FullName = Convert.ToString(Console.ReadLine()) };

                        //var classRoom = new ClassRoom() { Id = id, Name = name, School = school, Teacher = teacher };
                        //FluentNHibernateHelper.ReadItem(classRoom);
                        break;
                    }

                    if (selectedOption7 == "3")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher(incharge of class) fullname: ");
                        //Teacher teacher = new Teacher() { FullName = Convert.ToString(Console.ReadLine()) };

                        //var classRoom = new ClassRoom() { Id = id, Name = name, School = school, Teacher = teacher };
                        //FluentNHibernateHelper.UpdateItem(classRoom);
                        break;
                    }

                    if (selectedOption7 == "4")
                    {
                        //Console.Write("\nEnter clasroom Id: ");
                        //int id = Convert.ToInt32(Console.ReadLine());
                        //Console.Write("\nEnter clasroom name: ");
                        //string name = Convert.ToString(Console.ReadLine());
                        //Console.Write("\nEnter school name: ");
                        //School school = new School() { Name = Convert.ToString(Console.ReadLine()) };
                        //Console.Write("\nEnter teacher(incharge of class) fullname: ");
                        //Teacher teacher = new Teacher() { FullName = Convert.ToString(Console.ReadLine()) };

                        //var classRoom = new ClassRoom() { Id = id, Name = name, School = school, Teacher = teacher };
                        //FluentNHibernateHelper.DeleteItem(classRoom);
                        break;
                    }
                }
            }
        }
    }
    if (selectedOption == "9")
    {
        Console.Write("----------------------------------------------------------------------------------------------------------------------------\n");
        Console.Write("                                  **********       Reseting existing database       **********\n");
        Console.Write("----------------------------------------------------------------------------------------------------------------------------\n\n");
        FluentNHibernateHelper.ResetSessionFactory();
    }
}