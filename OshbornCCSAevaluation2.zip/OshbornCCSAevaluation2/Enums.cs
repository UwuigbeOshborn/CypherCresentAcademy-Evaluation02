﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2
{
    public enum Registration_Status
    {
        Registered,
        Unregistered
    }

    public enum Payment_Status
    {
        Paid,
        Owing
    }
    public enum BookAppointment_Status
    {
        Booked,
        NoBooking
    }
}