﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2
{
    public class Drug
    {
        //Constructors
        public Drug()
        {
            Patients = new List<Patient>();
        }
        //Methods

        //Properties
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Model { get; set; }
        public virtual string ProductionDate { get; set; }
        public virtual string ExpiringDate { get; set; }
        public virtual decimal Cost { get; set; }
        public virtual IList<Patient> Patients { get; set; }
    }
}
