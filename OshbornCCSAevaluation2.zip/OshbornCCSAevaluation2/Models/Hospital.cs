﻿using OshbornCCSAevaluation2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2
{
    public class Hospital
    {
        //Constructors
        public Hospital()
        {
            RegistationNumbers = new List<string>();
            HospitalNumbers = new List<string>();
            Doctors = new List<Doctor>();
            Receptionists = new List<Receptionist>();
            Pharmacists = new List<Pharmacist>();
            Nurses = new List<Nurse>();
            Accountants = new List<Accountant>();
            Patients = new List<Patient>();
        }
        //Methods

        //Properties
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Address { get; set; }
        public virtual IList<string> RegistationNumbers { get; set; }
        public virtual IList<string> HospitalNumbers { get; set; }
        public virtual IList<Doctor> Doctors { get; set; }
        public virtual IList<Receptionist> Receptionists { get; set; }
        public virtual IList<Pharmacist> Pharmacists { get; set; }
        public virtual IList<Nurse> Nurses { get; set; }
        public virtual IList<Accountant> Accountants { get; set; }
        public virtual IList<Patient> Patients { get; set; }
    }
}
