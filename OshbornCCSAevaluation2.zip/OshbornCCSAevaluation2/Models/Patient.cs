﻿using OshbornCCSAevaluation2.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2
{
    public class Patient
    {
        //Constructors
        public Patient()
        {
            Drugs = new List<Drug>();
        }
        public Patient(Hospital hospital)
        {
            Hospital = hospital;
        }
        //Methods

        public virtual void BookAppointment(Patient patient, Hospital hospital)
        {
            HospitalManager.BookAppointment(patient, hospital);
        }
        public virtual void Register(Patient patient, Hospital hospital)
        {
            HospitalManager.RegisterPatient(patient, hospital);
        }

        public virtual void SeeTheDoctor(Patient patient, Hospital hospital)
        {
            HospitalManager.SeeTheDoctorApproval(patient, hospital);
        }

        //Properties
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Address { get; set; }
        public virtual string PhoneNumber { get; set; }
        public virtual string RegistrationNumber { get; set; }
        public virtual string HospitalNumber { get; set; }
        public virtual Registration_Status Registrationstatus { get; set; }
        public virtual string RegistrationStatus { get; set; }
        public virtual Payment_Status Paymentstatus { get; set; }
        public virtual string PaymentStatus { get; set; }
        public virtual BookAppointment_Status BookAppointmentstatus { get; set; }
        public virtual string BookAppointmentStatus { get; set; }
        public virtual DateTime Appointment_Date { get; set; }
        public virtual string AppointmentDate { get; set; }
        public virtual Drug Drug { get; set; }
        public virtual IList<Drug> Drugs { get; set; }
        public virtual Doctor Doctor { get; set; }
        public virtual Hospital Hospital { get; set; }

    }
}
