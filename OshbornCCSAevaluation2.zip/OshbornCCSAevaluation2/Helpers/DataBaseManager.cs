﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Helpers
{
    public static class DataBaseManager
    {
        //Implementing CRUD
        public static void AddItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Save(item);
                    transaction.Commit();
                    Console.Write("\n----------------------New row-item successfully created--------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        //-------- Worked 1 Generic Get
        public static T ReadItem<T>(int id)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                var items = session.Get<T>(id);
                Console.Write("\n----------------------Item successfully read------------------\n");
                return items;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        // ------ worked 2 Generic query that takes the entityName as parameter
        public static List<T> ReadItem<T>(string entityName)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                var items = session.Query<T>(entityName).ToList();
                Console.Write("\n----------------------Item successfully read------------------\n");
                Console.Write($"There are {items.Count()} items in the list which are below\n\n");
                return items;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        // ------ worked 3 Generic query that takes no parameter
        public static List<T> ReadItem<T>()
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                var items = session.Query<T>().ToList();
                Console.Write("\n----------------------Item successfully read------------------\n");
                Console.Write($"There are {items.Count()} items in the list which are below\n\n");
                return items;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static void UpdateItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Update(item);
                    transaction.Commit();
                    Console.Write("\n----------------Row-item successfully updated------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Id does not exist");
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static void DeleteItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Delete(item);
                    transaction.Commit();
                    Console.Write("\n--------------------Item successfully deleted-------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }
    }
}
