﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Helpers
{
    public static class HospitalManager
    {
        //Constructors

        //Methods
        private static string GenerateRegistrationNumber(Hospital hospital)
        {
            string outPut = "";
            var randomNumbers = new Random();
            for (int i = 1; i <= 10; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in hospital.RegistationNumbers)
            {
                if (item == outPut)
                {
                    GenerateRegistrationNumber(hospital);
                }
            }
            hospital.RegistationNumbers.Add(outPut);
            return outPut;
        }

        private static string GenerateHospitalNumber(Hospital hospital)
        {
            string outPut = "";
            var randomNumbers = new Random();

            for (int i = 1; i <= 5; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in hospital.HospitalNumbers)
            {
                if (item == outPut)
                {
                    GenerateHospitalNumber(hospital);
                }
            }
            hospital.HospitalNumbers.Add(outPut);
            return outPut;
        }

        public static void RegisterPatient(Patient patient, Hospital hospital)
        {
            patient.RegistrationNumber = GenerateRegistrationNumber(hospital);
            patient.Registrationstatus = Registration_Status.Registered;
            patient.RegistrationStatus = Registration_Status.Registered.ToString();
            //patient.RegistrationStatus = "Registered";

            Console.WriteLine($"Hello {patient.Name}, you are now successfully registered, Your registration number is {patient.RegistrationNumber}");
            DataBaseManager.AddItem(patient);
        }

        public static void BookAppointment(Patient patient, Hospital hospital)
        {
            patient.HospitalNumber  = GenerateHospitalNumber(hospital);
            patient.BookAppointmentStatus = BookAppointment_Status.Booked.ToString();
            var randomDate = new Random();
            patient.AppointmentDate = DateTime.Now.AddDays(randomDate.Next(0, 5)).ToShortDateString();
            DataBaseManager.AddItem<Patient>(patient);
            Console.WriteLine($"Hello {patient.Name}, your booking was successfully, Your hospital number is {patient.HospitalNumber}, your appointment date is {patient.AppointmentDate}");
        }
        public static void BookAppointment(string patientRegistrationNumber, Hospital hospital, string patientName, string patienAddress, string patientPhoneNumber)
        {
            var allPatients = DataBaseManager.ReadItem<Patient>();
            bool flag1 = false;
            bool flag2 = false;
            foreach (var patientitem in allPatients)
            {
                if (patientitem.RegistrationNumber == patientRegistrationNumber)
                {
                    if (hospital.RegistationNumbers.Contains(patientRegistrationNumber))
                    {
                        if ((patientitem.PhoneNumber == patientPhoneNumber) || (patientitem.Name == patientName))
                        {
                            flag1 = true;
                            var randomDate = new Random();
                            var newPatient = new Patient() { Id = patientitem.Id, Name = patientName, Address = patienAddress, PhoneNumber = patientPhoneNumber, HospitalNumber = GenerateHospitalNumber(hospital), RegistrationNumber = patientRegistrationNumber, BookAppointmentStatus = BookAppointment_Status.Booked.ToString(), RegistrationStatus = Registration_Status.Registered.ToString(), AppointmentDate = DateTime.Now.AddDays(randomDate.Next(0, 5)).ToShortDateString(), Hospital = hospital };
                            DataBaseManager.UpdateItem<Patient>(newPatient);
                            // Set disccount property to true
                            Console.WriteLine($"Hello {patientName}, your booking was successfully with registration discount, your new hospital number is {newPatient.HospitalNumber}, and your appointment date is {newPatient.AppointmentDate}");
                            break;
                        }
                    }
                }
                flag2 = true;
            }
            if ((flag1 == false) && (flag2 = true))
            {
                var newPatient = new Patient() { Name = patientName, Address = patienAddress, PhoneNumber = patientPhoneNumber, Hospital = hospital };
                HospitalManager.BookAppointment(newPatient, hospital);
                Console.WriteLine($"Hello {newPatient.Name}, your booking was successfully with no registration discount because the registration number you entered does not exist");
            }
        }

        public static void SeeTheDoctorApproval(Patient patient, Hospital hospital)
        {
            if (patient.Registrationstatus is Registration_Status.Unregistered)
            {
                if (hospital.HospitalNumbers.Contains(patient.HospitalNumber))
                {
                    var currentDate = DateTime.Now;
                    if (patient.Appointment_Date == currentDate)
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Appointment();
                    }
                    else
                    {
                        Console.WriteLine($"Hello {patient.Name} your appoitment date {patient.AppointmentDate} is not today\n");
                    }
                }
                else
                {
                    Console.WriteLine($"Hello {patient.Name} please first generate your hospital number by booking an appointment to see the doctor");
                }
            }
            else if (patient.Registrationstatus is Registration_Status.Registered)
            {
                if (hospital.HospitalNumbers.Contains(patient.HospitalNumber))
                {
                    var currentDate = DateTime.Now;
                    if (patient.Appointment_Date == currentDate)
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Appointment();
                    }
                    else
                    {
                        Console.WriteLine($"Hello {patient.Name} your appoitment date {patient.AppointmentDate} is not today\n");
                    }
                }
                {
                    Console.WriteLine($"Hello {patient.Name}, you currently do not have any appointmet yet, I am about booking an appointment for you, please wait shortly\n");
                    Thread.Sleep(5000);
                    BookAppointment(patient, hospital);
                }
            }
        }
        public static void SeeTheDoctorApproval(string hospitalNumber, Hospital hospital)
        {
            var allPatients = DataBaseManager.ReadItem<Patient>();

            foreach (var patientitem in allPatients)
            {
                if (patientitem.HospitalNumber == hospitalNumber)
                {
                    if (patientitem.Registrationstatus is Registration_Status.Unregistered)
                    {
                        if (hospital.HospitalNumbers.Contains(hospitalNumber))
                        {
                            var currentDate = DateTime.Now.AddDays(0).ToShortDateString();
                            if (patientitem.AppointmentDate == currentDate)
                            {
                                Console.WriteLine("You can see the doctor now\n");
                                Appointment();
                                break;
                            }
                            else
                            {
                                Console.WriteLine($"Hello {patientitem.Name} your appoitment date {patientitem.AppointmentDate} is not today\n");
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Hello {patientitem.Name} please first generate your hospital number by booking an appointment to see the doctor");
                        }
                    }
                    else if (patientitem.Registrationstatus is Registration_Status.Registered)
                    {
                        if (hospital.HospitalNumbers.Contains(patientitem.HospitalNumber))
                        {
                            var currentDate = DateTime.Now.AddDays(0).ToShortDateString();
                            if (patientitem.AppointmentDate == currentDate)
                            {
                                Console.WriteLine("You can see the doctor now\n");
                                Appointment();
                                break;
                            }
                            else
                            {
                                Console.WriteLine($"Hello {patientitem.Name} your appoitment date {patientitem.AppointmentDate} is not today\n");
                                break;
                            }
                        }
                        {
                            Console.WriteLine($"Hello {patientitem.Name}, you currently do not have any appointmet yet, I am about booking an appointment for you, please wait shortly\n");
                            Thread.Sleep(5000);
                            BookAppointment(patientitem, hospital);
                            break;
                        }
                    }
                    break;
                }
            }
        }

        public static void Appointment()
        {
            Console.WriteLine("Reviewing medical condition");
            Console.WriteLine("Adminitration of drugs");
            Console.WriteLine("Billing Management");
        }


        //OTHER QUERY

        // Query 1:
        public static void ExstractAllDoctorsPatient(string doctorName)
        {
            try
            {
                bool flag1 = false;
                bool flag2 = false;
                var allPatients = DataBaseManager.ReadItem<Patient>();
                foreach (var content in allPatients)
                {
                    if (content.Doctor.Name == doctorName)
                    {
                        Console.WriteLine($"Patient Id:{content.Id}, Patient Name:{content.Name}, Patient Address{content.Address}\n");
                        flag1 = true;
                    }
                    else
                    {
                        flag2 = true;
                    }
                }
                if ((flag1 == false) && (flag2 == true))
                {
                    Console.WriteLine($"Hello {doctorName}, you currently do not have any patient scheduled for you today, please check another date");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there is no such doctor in the database");
            }
        }
        public static void ExstractAllDoctorsPatientWithDate(string doctorName, DateTime appointmentDate)
        {
            try
            {
                bool flag1 = false;
                bool flag2 = false;
                var allPatients = DataBaseManager.ReadItem<Patient>();
                foreach (var content in allPatients)
                {
                    if ((content.Doctor.Name == doctorName) && (content.AppointmentDate.Equals(appointmentDate.ToShortDateString())))
                    {
                        Console.WriteLine($"Patient Id:{content.Id}, Patient Name:{content.Name}, Patient Address{content.Address}\n");
                        flag1 = true;
                    }
                    else
                    {
                        flag2 = true;
                    }
                }
                if ((flag1 == false) && (flag2 == true))
                {
                    Console.WriteLine($"Hello {doctorName}, you currently do not have any patient scheduled for you today, please check another date");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there is no such doctor in the database");
            }
        }

        // Query 2:
        public static void AdminiterDrug(string doctorName, string patientName, string hospitalNumber, DateTime appointmentDate, Drug adminiteredDrug)
        {
            try
            {
                bool flag1 = false;
                bool flag2 = false;
                var allPatients = DataBaseManager.ReadItem<Patient>();
                foreach (var content in allPatients)
                {
                    if ((content.Doctor.Name == doctorName) && (content.Name == patientName) && (content.HospitalNumber == hospitalNumber) && (content.AppointmentDate.Equals(appointmentDate.ToShortDateString())))
                    {
                        content.Drugs.Add(adminiteredDrug);
                        Console.WriteLine($"Drugs adminitered successfully\n");
                        flag1 = true;
                    }
                    else
                    {
                        flag2 = true;
                    }
                }
                if ((flag1 == false) && (flag2 == true))
                {
                    Console.WriteLine($"Hello {doctorName}, you currently do not have any patient of such");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there is no such doctor in the database");
            }
        }


        // Query 3:
        public static void AllDoctorsInHospital()
        {
            var allHospitals = DataBaseManager.ReadItem<Hospital>();
            foreach (var hospitalitem in allHospitals)
            {
                Console.WriteLine($" The following doctors are working at {hospitalitem.Name} hospital: ({String.Join(", ", hospitalitem.Doctors.Select(s => s.Name))})\n");
            }
        }


        // query 4
        public static void AllHospitalPatients()
        {
            var allHospitals2 = DataBaseManager.ReadItem<Hospital>();
            foreach (var hospitalitem in allHospitals2)
            {
                Console.WriteLine($" The following Patients are admitted into {hospitalitem.Name} hospital: ({String.Join(", ", hospitalitem.Patients.Select(s => s.Name))})\n");
            }
        }
        public static IList<Patient> AllHospitalPatients(int hospitalId)
        {
            var hospital = DataBaseManager.ReadItem<Hospital>(hospitalId);
            return hospital.Patients;
        }



        // Query 5 
        public static void AllRegisteredHospitalPatient()
        {
            var allPatients2 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients2)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.RegistrationStatus == Registration_Status.Registered.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is registered");
                }
            }
        }

        
        public static void AllUnregisteredHospitalPatient()
        {
            var allPatients2 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients2)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.RegistrationStatus == Registration_Status.Unregistered.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is unregistered");
                }
            }
        }

        // Query 6
        public static void AllOwingHospitalPatient()
        {
            var allPatients3 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients3)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.PaymentStatus == Payment_Status.Owing.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is still owing");
                }
            }
        }

        public static void AllPaidHospitalPatient()
        {
            var allPatients3 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients3)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.PaymentStatus == Payment_Status.Paid.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is has paid");
                }
            }
        }

        // Query 7
        public static void TopTenDrugsSales()
        {
            try
            {
                Console.WriteLine($"The Top ten most bought Drugs are:\n");
                var allPatients4 = DataBaseManager.ReadItem<Patient>();
                int counter = 0, tempCounter = 1, foundNumber = 0, counter2 = 0;
                var drugList = new List<int>();
                foreach (var patientitem in allPatients4)
                {
                    drugList.Add(patientitem.Drug.Id);
                }
                drugList.Sort();

                for (int i = 0; i < drugList.Count - 1; i++)
                {
                    for (int j = 0; j < drugList.Count - 1; j++)
                    {
                        if (drugList[j] == drugList[j + 1]) tempCounter++;
                        else tempCounter = 1;
                        if (tempCounter > counter)
                        {
                            counter = tempCounter;
                            foundNumber = drugList[j];
                        }
                    }
                    drugList.RemoveAll(content => content == foundNumber);
                    var items1 = DataBaseManager.ReadItem<Drug>(foundNumber);
                    counter = 0;
                    tempCounter = 1;
                    Console.WriteLine($"Drug Name: {items1.Name},  and it cost: {items1.Cost}\n");

                    counter2++;
                    if (counter2 == 10)
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        // Other Queries

        public static void TopOneDrugsSales()
        {
            try
            {
                var allPatients4 = DataBaseManager.ReadItem<Patient>();
                int counter = 0, tempCounter = 1, foundNumber = 0;
                var drugList = new List<int>();
                foreach (var patientitem in allPatients4)
                {
                    drugList.Add(patientitem.Drug.Id);
                }
                drugList.Sort();

                for (int i = 0; i < drugList.Count - 1; i++)
                {
                    if (drugList[i] == drugList[i + 1]) tempCounter++;
                    else tempCounter = 1;
                    if (tempCounter > counter)
                    {
                        counter = tempCounter;
                        foundNumber = drugList[i];
                    }
                }
                var items = DataBaseManager.ReadItem<Drug>(foundNumber);
                Console.WriteLine($"The most bought drug is {items.Name},  and it cost: {items.Cost}\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        public static void MostExpensiveDrugs()
        {
            try
            {
                var allDrugs = DataBaseManager.ReadItem<Drug>();
                var drugList = new List<decimal>();
                foreach (var drugitem in allDrugs)
                {
                    drugList.Add(drugitem.Cost);
                }
                drugList.Sort();

                var mustExpensiveDrug = drugList.Max();

                foreach (var drugitem in allDrugs)
                {
                    if (drugitem.Cost == mustExpensiveDrug)
                    {
                        Console.WriteLine($"Drug Name: {drugitem.Name} is the most expensive drug in our database, it cost N{mustExpensiveDrug}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        public static void DrugsPriceFilter(decimal drugPrice)
        {
            try
            {
                var alldrugs = DataBaseManager.ReadItem<Drug>();
                foreach (var drugitem in alldrugs)
                {
                    if (drugitem.Cost > drugPrice)
                    {
                        Console.WriteLine($"Drug Name: {drugitem.Name} is above N{drugPrice} price");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }

    }
}
