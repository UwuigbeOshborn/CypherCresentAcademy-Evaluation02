﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Helpers
{
    public static class HospitalManager
    {
        //Constructors

        //Methods
        private static string GenerateRegistrationNumber(Hospital hospital)
        {
            string outPut = "";
            var randomNumbers = new Random();
            for (int i = 1; i <= 10; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in hospital.RegistationNumbers)
            {
                if (item == outPut)
                {
                    GenerateRegistrationNumber(hospital);
                }
            }
            hospital.RegistationNumbers.Add(outPut);
            return outPut;
        }

        private static string GenerateHospitalNumber(Hospital hospital)
        {
            string outPut = "";
            var randomNumbers = new Random();

            for (int i = 1; i <= 5; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in hospital.HospitalNumbers)
            {
                if (item == outPut)
                {
                    GenerateHospitalNumber(hospital);
                }
            }
            hospital.HospitalNumbers.Add(outPut);
            return outPut;
        }

        public static void RegisterPatient(Patient patient, Hospital hospital)
        {
            patient.RegistrationNumber = GenerateRegistrationNumber(hospital);
            patient.Registrationstatus = Registration_Status.Registered;
            patient.RegistrationStatus = Registration_Status.Registered.ToString();
            //patient.RegistrationStatus = "Registered";

            Console.WriteLine($"Hello {patient.Name}, you are now successfully registered, Your registration number is {patient.RegistrationNumber}");
            DataBaseManager.AddItem(patient);
        }

        public static void BookAppointment(Patient patient, Hospital hospital)
        {
            patient.HospitalNumber  = GenerateHospitalNumber(hospital);

            Console.WriteLine($"Hello {patient.Name}, your booking was successfully, Your hospital number is {patient.HospitalNumber}");
        }

        public static void SeeTheDoctorApproval(Patient patient, Hospital hospital)
        {
            if (patient.Registrationstatus is Registration_Status.Unregistered)
            {
                if (hospital.HospitalNumbers.Contains(patient.HospitalNumber))
                {
                    var currentDate = DateTime.Now;
                    if (patient.Appointment_Date == currentDate)
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Appointment();
                    }
                    else
                    {
                        Console.WriteLine($"Hello {patient.Name} your appoitment date {patient.AppointmentDate} is not today\n");
                    }
                }
                else
                {
                    Console.WriteLine($"Hello {patient.Name} please first generate your hospital number by booking an appointment to see the doctor");
                }
            }
            else if (patient.Registrationstatus is Registration_Status.Registered)
            {
                if (hospital.HospitalNumbers.Contains(patient.HospitalNumber))
                {
                    var currentDate = DateTime.Now;
                    if (patient.Appointment_Date == currentDate)
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Appointment();
                    }
                    else
                    {
                        Console.WriteLine($"Hello {patient.Name} your appoitment date {patient.AppointmentDate} is not today\n");
                    }
                }
                {
                    Console.WriteLine($"Hello {patient.Name}, you currently do not have any appointmet yet, I am about booking an appointment for you, please wait shortly\n");
                    Thread.Sleep(5000);
                    BookAppointment(patient, hospital);
                }
            }
        }
        public static void Appointment()
        {
            Console.WriteLine("Reviewing medical condition");
            Console.WriteLine("Adminitration of drugs");
            Console.WriteLine("Billing Management");
        }


        //OTHER QUERY

        // Query 1:
        public static void ExstractAllDoctorsPatient(string doctorName, DateTime date)
        {
            try
            {
                bool flag1 = false;
                bool flag2 = false;
                var allPatients = DataBaseManager.ReadItem<Patient>();
                foreach (var content in allPatients)
                {
                    if ((content.Doctor.Name == doctorName) && (content.AppointmentDate.Equals(date.ToShortDateString())))
                    {
                        Console.WriteLine($"Patient Id:{content.Id}, Patient Name:{content.Name}, Patient Address{content.Address}\n");
                        flag1 = true;
                    }
                    else
                    {
                        flag2 = true;
                    }
                }
                if ((flag1 == false) && (flag2 == true))
                {
                    Console.WriteLine($"Hello {doctorName}, you currently do not have any patient scheduled for you today, place check another date");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there is no such doctor in the database");
            }
        }

        // Query 2:



        // Query 3:
        public static void AllDoctorsInHospital()
        {
            var allHospitals = DataBaseManager.ReadItem<Hospital>();
            foreach (var hospitalitem in allHospitals)
            {
                Console.WriteLine($" The following doctors are working at {hospitalitem.Name} hospital: ({String.Join(", ", hospitalitem.Doctors.Select(s => s.Name))})\n");
            }
        }


        // query 4
        public static void AllHospitalPatients()
        {
            var allHospitals2 = DataBaseManager.ReadItem<Hospital>();
            foreach (var hospitalitem in allHospitals2)
            {
                Console.WriteLine($" The following Patients are admitted into {hospitalitem.Name} hospital: ({String.Join(", ", hospitalitem.Patients.Select(s => s.Name))})\n");
            }
        }



        // Query 5 
        public static void AllRegisteredHospitalPatient()
        {
            var allPatients2 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients2)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.RegistrationStatus == Registration_Status.Registered.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is registered");
                }
            }
        }

        
        public static void AllUnregisteredHospitalPatient()
        {
            var allPatients2 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients2)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.RegistrationStatus == Registration_Status.Unregistered.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is unregistered");
                }
            }
        }

        // Query 6
        public static void AllOwingHospitalPatient()
        {
            var allPatients3 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients3)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.PaymentStatus == Payment_Status.Owing.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is still owing");
                }
            }
        }

        public static void AllPaidHospitalPatient()
        {
            var allPatients3 = DataBaseManager.ReadItem<Patient>();
            foreach (var patientitem in allPatients3)
            {
                if ((patientitem.Hospital.Name == "Royal Health Care") && (patientitem.PaymentStatus == Payment_Status.Paid.ToString()))
                {
                    Console.WriteLine($"{patientitem.Name} is has paid");
                }
            }
        }

        // Query 7
        public static void TopTenDrugsSales()
        {
            try
            {
                Console.WriteLine($"The Top ten most bought Drugs are:\n");
                var allPatients4 = DataBaseManager.ReadItem<Patient>();
                int counter = 0, tempCounter = 1, foundNumber = 0, counter2 = 0;
                var drugList = new List<int>();
                foreach (var patientitem in allPatients4)
                {
                    drugList.Add(patientitem.Drug.Id);
                }
                drugList.Sort();

                for (int i = 0; i < drugList.Count - 1; i++)
                {
                    for (int j = 0; j < drugList.Count - 1; j++)
                    {
                        if (drugList[j] == drugList[j + 1]) tempCounter++;
                        else tempCounter = 1;
                        if (tempCounter > counter)
                        {
                            counter = tempCounter;
                            foundNumber = drugList[j];
                        }
                    }
                    drugList.RemoveAll(content => content == foundNumber);
                    var items1 = DataBaseManager.ReadItem<Drug>(foundNumber);
                    counter = 0;
                    tempCounter = 1;
                    Console.WriteLine($"Drug Name: {items1.Name},  and it cost: {items1.Cost}\n");

                    counter2++;
                    if (counter2 == 10)
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        // Other Queries

        public static void TopOneDrugsSales()
        {
            try
            {
                var allPatients4 = DataBaseManager.ReadItem<Patient>();
                int counter = 0, tempCounter = 1, foundNumber = 0;
                var drugList = new List<int>();
                foreach (var patientitem in allPatients4)
                {
                    drugList.Add(patientitem.Drug.Id);
                }
                drugList.Sort();

                for (int i = 0; i < drugList.Count - 1; i++)
                {
                    if (drugList[i] == drugList[i + 1]) tempCounter++;
                    else tempCounter = 1;
                    if (tempCounter > counter)
                    {
                        counter = tempCounter;
                        foundNumber = drugList[i];
                    }
                }
                var items = DataBaseManager.ReadItem<Drug>(foundNumber);
                Console.WriteLine($"The most bought drug is {items.Name},  and it cost: {items.Cost}\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        public static void MostExpensiveDrugs()
        {
            try
            {
                var allDrugs = DataBaseManager.ReadItem<Drug>();
                int counter = 0, tempCounter = 1;
                decimal foundNumber = 0;
                var drugList = new List<decimal>();
                foreach (var drugitem in allDrugs)
                {
                    drugList.Add(drugitem.Cost);
                }
                drugList.Sort();

                for (int i = 0; i < drugList.Count - 1; i++)
                {
                    if (drugList[i] == drugList[i + 1]) tempCounter++;
                    else tempCounter = 1;
                    if (tempCounter > counter)
                    {
                        counter = tempCounter;
                        foundNumber = drugList[i];
                    }
                }
                foreach (var drugitem in allDrugs)
                {
                    if (drugitem.Cost == foundNumber)
                    {
                        Console.WriteLine($"Drug Name: {drugitem.Name} is the most expensive drug in our database, it cost N{foundNumber}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }


        public static void DrugsPriceFilter(decimal drugPrice)
        {
            try
            {
                var alldrugs = DataBaseManager.ReadItem<Drug>();
                foreach (var drugitem in alldrugs)
                {
                    if (drugitem.Cost > drugPrice)
                    {
                        Console.WriteLine($"Drug Name: {drugitem.Name} is above N{drugPrice} price");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("It seems there are no drugs in the database");
            }
        }

    }
}
