﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Mapping
{
    public class ReceptionistMap : ClassMap<Receptionist>
    {
        public ReceptionistMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            References(x => x.Patient);
            References(x => x.Hospital).Column("Hospital_id");
        }
    }
}
