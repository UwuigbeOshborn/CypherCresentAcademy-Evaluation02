﻿using FluentNHibernate.Mapping;
using OshbornCCSAevaluation2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Mapping
{
    public class PharmacistMap : ClassMap<Pharmacist>
    {
        public PharmacistMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            References(x => x.Patient);
            References(x => x.Hospital).Column("Hospital_id");
        }
    }
}