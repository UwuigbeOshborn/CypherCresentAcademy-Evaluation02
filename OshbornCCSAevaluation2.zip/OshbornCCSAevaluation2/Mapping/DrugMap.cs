﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Mapping
{
    public class DrugMap : ClassMap<Drug>
    {
        public DrugMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Model);
            Map(x => x.ProductionDate);
            Map(x => x.ExpiringDate);
            Map(x => x.Cost);
            HasMany(x => x.Patients).KeyColumn("Drug_id").Inverse().Cascade.All();
        }
    }
}