﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Mapping
{
    public class PatientMap : ClassMap<Patient>
    {
        public PatientMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            Map(x => x.RegistrationNumber);
            Map(x => x.HospitalNumber);
            Map(x => x.RegistrationStatus);
            Map(x => x.PaymentStatus);
            Map(x => x.BookAppointmentStatus);
            Map(x => x.AppointmentDate);
            References(x => x.Drug).Column("Drug_id");
            References(x => x.Hospital).Column("Hospital_id");
            References(x => x.Doctor);
        }
    }
} 