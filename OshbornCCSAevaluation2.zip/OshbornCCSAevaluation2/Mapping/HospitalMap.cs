﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation2.Mapping
{
    public class HospitalMap : ClassMap<Hospital>
    {
        public HospitalMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            HasMany(x => x.Doctors).KeyColumn("Hospital_id").Inverse().Cascade.All();
            HasMany(x => x.Receptionists).KeyColumn("Hospital_id").Inverse().Cascade.All();
            HasMany(x => x.Pharmacists).KeyColumn("Hospital_id").Inverse().Cascade.All();
            HasMany(x => x.Nurses).KeyColumn("Hospital_id").Inverse().Cascade.All();
            HasMany(x => x.Accountants).KeyColumn("Hospital_id").Inverse().Cascade.All();
            HasMany(x => x.Patients).KeyColumn("Hospital_id").Inverse().Cascade.All();
        }
    }
}
